import React, { Component } from 'react'
import Appcontainer from "./navigation/Appcontainer"
import { View, Text, TextInput, ScrollView } from 'react-native'
export default class App extends Component {
  render() {
    return <Appcontainer />
  }
}
